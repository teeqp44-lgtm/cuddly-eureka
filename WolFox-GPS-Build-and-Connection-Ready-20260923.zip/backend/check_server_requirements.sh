#!/usr/bin/env bash
set -u

# فحص محلي فقط: لا ينزّل أي حزمة ولا يتصل بمستودعات خارجية.
account_root="${WOLFOX_ACCOUNT_ROOT:-/home/u460057331}"
panel_root="${WOLFOX_PANEL_ROOT:-$account_root/domains/gps.p3nd.fun/public_html/android/wolfox-admin}"
sdk_root="${ANDROID_SDK_ROOT:-$account_root/android-sdk}"
java_bin="${JAVA_BIN:-$sdk_root/jdk-17/bin/java}"
build_tools="${ANDROID_BUILD_TOOLS:-$sdk_root/build-tools/34.0.0}"
failures=0
warnings=0

ok() { printf '[ناجح] %s\n' "$1"; }
bad() { printf '[مفقود] %s\n' "$1" >&2; failures=$((failures + 1)); }
warn() { printf '[تنبيه] %s\n' "$1" >&2; warnings=$((warnings + 1)); }

if [[ -n "${WOLFOX_BUILDER_ROOT:-}" ]]; then
  builder_root="$WOLFOX_BUILDER_ROOT"
elif [[ -d "$panel_root/builder-" ]]; then
  builder_root="$panel_root/builder-"
elif [[ -d "$panel_root/builder" ]]; then
  builder_root="$panel_root/builder"
else
  builder_root="$panel_root/builder-"
fi

echo "WolFox — فحص الأدوات المحلية"
echo "Panel:   $panel_root"
echo "Builder: $builder_root"
echo "SDK:     $sdk_root"

if command -v php >/dev/null 2>&1; then
  if php -r 'exit(PHP_VERSION_ID >= 80100 ? 0 : 1);'; then
    ok "PHP $(php -r 'echo PHP_VERSION;')"
  else
    bad "PHP 8.1 أو أحدث مطلوب"
  fi
  if php -r 'exit(extension_loaded("pdo_mysql") ? 0 : 1);'; then
    ok "pdo_mysql"
  else
    bad "إضافة PHP pdo_mysql"
  fi
else
  bad "أمر php"
fi

if command -v python3 >/dev/null 2>&1; then
  ok "$(python3 --version 2>&1)"
else
  bad "python3"
fi

ensure_executable() {
  local label="$1"
  local path="$2"
  if [[ ! -f "$path" ]]; then
    bad "$label: $path"
    return
  fi
  chmod 0755 "$path" 2>/dev/null || warn "تعذر ضبط 0755 على $path"
  if [[ -x "$path" ]]; then
    ok "$label: $path"
  else
    bad "$label موجود لكنه غير قابل للتنفيذ: $path"
  fi
}

ensure_executable "Java 17" "$java_bin"
ensure_executable "aapt2" "$build_tools/aapt2"
ensure_executable "apksigner" "$build_tools/apksigner"
ensure_executable "zipalign" "$build_tools/zipalign"

if [[ -f "$builder_root/tools/safe_patch.py" ]]; then
  ensure_executable "Safe patch engine" "$builder_root/tools/safe_patch.py"
else
  bad "Safe patch engine: $builder_root/tools/safe_patch.py"
fi

for required in \
  "$builder_root/tools/manifest-editor.jar" \
  "$builder_root/tools/runtime/metaloader.dex" \
  "$builder_root/tools/runtime/loader.dex" \
  "$builder_root/tools/runtime/runtime-config.json" \
  "$builder_root/tools/wolfox-module.apk"
do
  if [[ -f "$required" ]]; then ok "$required"; else bad "$required"; fi
done

for abi in armeabi-v7a arm64-v8a x86 x86_64; do
  runtime="$builder_root/tools/runtime/so/$abi/liblspatch.so"
  if [[ -f "$runtime" ]]; then ok "Runtime $abi"; else bad "$runtime"; fi
done

storage_root="$panel_root/storage"
if mkdir -p "$storage_root/build-jobs" "$storage_root/uploads" "$storage_root/output" 2>/dev/null; then
  chmod 0750 "$storage_root" "$storage_root/build-jobs" \
    "$storage_root/uploads" "$storage_root/output" 2>/dev/null \
    || warn "تعذر ضبط صلاحيات بعض مجلدات العمل"
  if [[ -w "$storage_root/build-jobs" ]]; then
    ok "مجلد العمل قابل للكتابة: $storage_root/build-jobs"
  else
    bad "مجلد العمل غير قابل للكتابة: $storage_root/build-jobs"
  fi
else
  bad "تعذر إنشاء مجلدات العمل تحت $storage_root"
fi

keystore="${WOLFOX_KEYSTORE_PATH:-$account_root/.secrets/wolfox-release.jks}"
if [[ -f "$keystore" ]]; then
  chmod 0600 "$keystore" 2>/dev/null || warn "تعذر ضبط 0600 لملف التوقيع"
  ok "ملف التوقيع المحلي: $keystore"
else
  bad "ملف التوقيع: $keystore"
fi

if [[ -x "$java_bin" ]]; then "$java_bin" -version >/dev/null 2>&1 || bad "Java لا يعمل"; fi
if [[ -x "$build_tools/aapt2" ]]; then "$build_tools/aapt2" version >/dev/null 2>&1 || bad "aapt2 لا يعمل"; fi
if [[ -x "$build_tools/apksigner" ]]; then "$build_tools/apksigner" version >/dev/null 2>&1 || bad "apksigner لا يعمل"; fi
if [[ -x "$build_tools/zipalign" ]]; then "$build_tools/zipalign" -h >/dev/null 2>&1 || true; fi

printf '\nالنتيجة: %d أخطاء، %d تنبيهات.\n' "$failures" "$warnings"
if (( failures > 0 )); then
  echo "صحح العناصر المفقودة محليًا ثم أعد الفحص." >&2
  exit 1
fi
echo "كل متطلبات الدمج المحلية اجتازت الفحص."

