#!/usr/bin/env bash
set -euo pipefail

project_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
sdk_root="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-$project_dir/../toolchain/android-sdk}}"
missing=0

check_command() {
  if command -v "$1" >/dev/null 2>&1; then
    printf 'OK: %s\n' "$1"
  else
    printf 'MISSING: %s\n' "$1" >&2
    missing=1
  fi
}

for command_name in java javac keytool zip unzip; do check_command "$command_name"; done
if command -v java >/dev/null 2>&1; then
  java -version 2>&1 | head -1
fi
if command -v javac >/dev/null 2>&1; then
  javac -version
fi
if command -v java >/dev/null 2>&1 && ! java -version 2>&1 | head -1 | grep -Eq 'version "17([.\"]|$)'; then
  printf 'MISSING: Java 17 is required for build-local.sh\n' >&2
  missing=1
fi

for required in \
  "$sdk_root/platforms/android-34/android.jar" \
  "$sdk_root/build-tools/34.0.0/aapt2" \
  "$sdk_root/build-tools/34.0.0/d8" \
  "$sdk_root/build-tools/34.0.0/zipalign" \
  "$sdk_root/build-tools/34.0.0/apksigner"; do
  if [[ -f "$required" ]]; then
    printf 'OK: %s\n' "$required"
  else
    printf 'MISSING: %s\n' "$required" >&2
    missing=1
  fi
done

if (( missing )); then
  printf 'Install JDK 17 and Android SDK Platform 34 + Build Tools 34.0.0, or use GitHub Actions.\n' >&2
  exit 2
fi
printf 'Build prerequisites present. For a test APK run: WOLFOX_ALLOW_TEST_KEYSTORE=1 ./build-local.sh\n'
