<?php require __DIR__.'/bootstrap.php';
$error='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
  check_csrf();
  $fails=(int)($_SESSION['login_fails']??0); $last=(int)($_SESSION['login_last_fail']??0);
  if($fails>=6 && time()-$last<300){ $error='محاولات كثيرة. أعد المحاولة بعد خمس دقائق.'; }
  else {
  $u=trim((string)($_POST['username']??'')); $p=(string)($_POST['password']??'');
  $st=$pdo->prepare('SELECT * FROM wolfox_admin_users WHERE username=? AND active=1 LIMIT 1'); $st->execute([$u]); $row=$st->fetch();
  if ($row && password_verify($p, $row['password_hash'])) { session_regenerate_id(true); $_SESSION['login_fails']=0; $_SESSION['admin_user']=$row['username']; $_SESSION['role']=$row['role']; $pdo->prepare('UPDATE wolfox_admin_users SET last_login_at=UTC_TIMESTAMP() WHERE id=?')->execute([$row['id']]); audit($pdo,'login'); header('Location: index.php'); exit; }
  $_SESSION['login_fails']=$fails+1; $_SESSION['login_last_fail']=time(); $error='بيانات الدخول غير صحيحة';
  }
}
?><!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>WolFox Login</title><link rel="stylesheet" href="style.css"></head><body><main class="login"><form class="card" method="post"><h1>WolFox</h1><p>دخول لوحة الإدارة</p><?php if($error):?><div class="alert"><?=h($error)?></div><?php endif?><input type="hidden" name="csrf" value="<?=h(csrf())?>"><label>اسم المستخدم<input name="username" required></label><label>كلمة المرور<input name="password" type="password" required></label><button>دخول</button></form></main></body></html>
