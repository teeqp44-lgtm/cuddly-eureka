<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, max-age=0');
header('Pragma: no-cache');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');
if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
    header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
}

require dirname(__DIR__, 4) . '/android/wolfox-admin/config.php';

function control_response(int $http, array $data): never {
    http_response_code($http);
    $data['server_time'] = gmdate('c');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'GET') {
    header('Allow: GET');
    control_response(405, ['ok' => false, 'status' => 'MethodNotAllowed']);
}

$package = substr(trim((string)($_GET['package_name'] ?? 'com.wolfox.gps')), 0, 191);
$versionCode = max(0, (int)($_GET['version_code'] ?? 0));
if (!preg_match('/^[A-Za-z][A-Za-z0-9_.]{2,190}$/', $package)) {
    control_response(422, ['ok' => false, 'status' => 'InvalidPackage']);
}

try {
    $statement = $pdo->prepare('SELECT * FROM wolfox_app_control WHERE package_name=? LIMIT 1');
    $statement->execute([$package]);
    $policy = $statement->fetch();
    if (!$policy) {
        control_response(200, [
            'ok' => true, 'blocked' => false, 'update_required' => false,
            'message_title' => '', 'message_text' => '',
            'store_deep_link' => '', 'update_page' => ''
        ]);
    }

    $updateRequired = (bool)$policy['force_update']
        && $versionCode < (int)$policy['min_version_code'];
    $blocked = !(bool)$policy['enabled'] || (bool)$policy['maintenance'] || $updateRequired;
    $title = trim((string)($policy['message_title'] ?? ''));
    $message = trim((string)($policy['message_text'] ?? ''));
    if ($title === '') {
        $title = $updateRequired ? 'تحديث إجباري'
            : ((bool)$policy['maintenance'] ? 'صيانة مؤقتة' : 'الخدمة غير متاحة');
    }
    if ($message === '') {
        $message = $updateRequired ? 'يجب تحديث الموديول للمتابعة.'
            : ((bool)$policy['maintenance'] ? 'الخدمة تحت الصيانة، حاول لاحقًا.' : 'حاول مرة أخرى لاحقًا.');
    }

    control_response(200, [
        'ok' => true,
        'blocked' => $blocked,
        'update_required' => $updateRequired,
        'minimum_version_code' => (int)$policy['min_version_code'],
        'message_title' => $blocked ? $title : '',
        'message_text' => $blocked ? $message : '',
        'store_deep_link' => $updateRequired ? (string)($policy['store_deep_link'] ?? '') : '',
        'update_page' => $updateRequired ? (string)($policy['update_page'] ?? '') : ''
    ]);
} catch (Throwable $error) {
    error_log('WolFox control: ' . $error->getMessage());
    // Fail open: a temporary server/schema problem must not disable active clients.
    control_response(200, [
        'ok' => true, 'blocked' => false, 'update_required' => false,
        'message_title' => '', 'message_text' => '',
        'store_deep_link' => '', 'update_page' => '', 'degraded' => true
    ]);
}
