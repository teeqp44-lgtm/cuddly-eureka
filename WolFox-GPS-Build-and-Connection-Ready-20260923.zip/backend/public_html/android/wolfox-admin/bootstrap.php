<?php
declare(strict_types=1);
$config = __DIR__ . '/config.php';
if (!is_file($config)) { http_response_code(500); exit('Missing config.php. Copy config.example.php and set DB credentials.'); }
require_once $config;
if (!defined('WOLFOX_ANDROID_BASE_URL')) {
    define('WOLFOX_ANDROID_BASE_URL', 'https://gps.p3nd.fun/android/wolfox-admin');
}
if (!defined('WOLFOX_ANDROID_SESSION_NAME')) {
    define('WOLFOX_ANDROID_SESSION_NAME', 'wolfox_android_admin_session');
}
session_name(WOLFOX_ANDROID_SESSION_NAME);
session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/android/wolfox-admin/',
    'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    'httponly' => true,
    'samesite' => 'Strict',
]);
session_start();
function h(string $v): string { return htmlspecialchars($v, ENT_QUOTES, 'UTF-8'); }
function csrf(): string { if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(24)); return $_SESSION['csrf']; }
function check_csrf(): void { if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) { http_response_code(403); exit('CSRF'); } }
function require_login(): void { if (empty($_SESSION['admin_user'])) { header('Location: login.php'); exit; } }
function require_write_access(): void {
    require_login();
    if (($_SESSION['role'] ?? 'viewer') === 'viewer') {
        http_response_code(403); exit('Read only');
    }
}
function audit(PDO $pdo, string $action, ?string $code=null, ?string $details=null): void {
    $st=$pdo->prepare('INSERT INTO wolfox_admin_audit(actor,action,license_code,details,ip) VALUES(?,?,?,?,?)');
    $st->execute([$_SESSION['admin_user'] ?? null, $action, $code, $details, $_SERVER['REMOTE_ADDR'] ?? null]);
}
function make_code(): string {
    return 'WFX' . strtoupper(bin2hex(random_bytes(8)));
}
