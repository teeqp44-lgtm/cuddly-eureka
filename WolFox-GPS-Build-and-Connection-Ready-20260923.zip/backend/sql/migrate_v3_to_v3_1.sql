CREATE TABLE IF NOT EXISTS wolfox_app_control (
  package_name VARCHAR(191) PRIMARY KEY,
  enabled TINYINT(1) NOT NULL DEFAULT 1,
  maintenance TINYINT(1) NOT NULL DEFAULT 0,
  min_version_code INT UNSIGNED NOT NULL DEFAULT 0,
  force_update TINYINT(1) NOT NULL DEFAULT 0,
  message_title VARCHAR(191) NULL,
  message_text VARCHAR(500) NULL,
  store_deep_link VARCHAR(500) NULL,
  update_page VARCHAR(500) NULL,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO wolfox_app_control(package_name,enabled,maintenance,min_version_code,force_update)
VALUES('com.wolfox.gps',1,0,0,0)
ON DUPLICATE KEY UPDATE package_name=VALUES(package_name);
