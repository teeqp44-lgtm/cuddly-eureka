<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, max-age=0');
header('Pragma: no-cache');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');
if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
    header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
}

require dirname(__DIR__, 3) . '/android/wolfox-admin/config.php';

function respond(int $http, array $data): never {
    http_response_code($http);
    $data['server_time'] = gmdate('c');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    header('Allow: POST');
    respond(405, ['status' => 'MethodNotAllowed']);
}

$contentLength = (int)($_SERVER['CONTENT_LENGTH'] ?? 0);
if ($contentLength > 65536) respond(413, ['status' => 'PayloadTooLarge']);

$raw = file_get_contents('php://input') ?: '';
$input = json_decode($raw, true);
if (!is_array($input)) respond(400, ['status' => 'InvalidRequest', 'message' => 'Invalid JSON']);

$rawCode = strtoupper(trim((string)($input['code'] ?? $input['license_code'] ?? '')));
$code = preg_replace('/[^A-Z0-9]/', '', $rawCode) ?: '';
$installation = trim((string)($input['installation_id'] ?? ''));
$binding = strtolower(trim((string)($input['device_binding'] ?? '')));
$platform = strtolower(trim((string)($input['platform'] ?? 'android')));
$project = trim((string)($input['project'] ?? 'WolFox GPS'));
$appVersion = substr(trim((string)($input['app_version'] ?? '')), 0, 32);
$packageName = substr(trim((string)($input['package_name'] ?? '')), 0, 191);
$deviceModel = substr(trim((string)($input['device_model'] ?? '')), 0, 191);
$requestId = substr(trim((string)($input['request_id'] ?? '')), 0, 64);

if ($code === '' || strlen($code) > 64
    || $installation === '' || strlen($installation) > 191
    || !preg_match('/^[a-f0-9]{64}$/', $binding)
    || $platform !== 'android') {
    respond(422, ['status' => 'InvalidRequest', 'request_id' => $requestId]);
}

try {
    $pdo->beginTransaction();
    $statement = $pdo->prepare('SELECT * FROM wolfox_licenses WHERE code = ? FOR UPDATE');
    $statement->execute([$code]);
    $license = $statement->fetch();

    // توافق انتقالي مع الأكواد القديمة التي كانت تحتوي على فواصل.
    if (!$license) {
        $statement = $pdo->prepare(
            "SELECT * FROM wolfox_licenses
             WHERE REPLACE(REPLACE(REPLACE(UPPER(code),'-',''),'_',''),' ','') = ?
             LIMIT 1 FOR UPDATE"
        );
        $statement->execute([$code]);
        $license = $statement->fetch();
    }

    if (!$license) {
        $pdo->rollBack();
        respond(404, ['status' => 'InvalidCode', 'request_id' => $requestId]);
    }
    if ($license['status'] === 'Disabled') {
        $pdo->rollBack();
        respond(403, ['status' => 'Disabled', 'request_id' => $requestId]);
    }

    if (!empty($license['expires_at']) && strtotime((string)$license['expires_at']) <= time()) {
        $pdo->prepare("UPDATE wolfox_licenses SET status='Expired' WHERE id=?")
            ->execute([$license['id']]);
        $pdo->commit();
        respond(403, [
            'status' => 'Expired',
            'expires_at' => $license['expires_at'],
            'expires_at_epoch' => strtotime((string)$license['expires_at']),
            'request_id' => $requestId,
        ]);
    }

    $boundInstallation = (string)($license['installation_id'] ?? '');
    $boundDevice = strtolower((string)($license['device_binding'] ?? ''));
    if (($boundInstallation !== '' && !hash_equals($boundInstallation, $installation))
        || ($boundDevice !== '' && !hash_equals($boundDevice, $binding))) {
        $pdo->rollBack();
        respond(409, ['status' => 'TransferRequired', 'request_id' => $requestId]);
    }

    $firstActivation = empty($license['activated_at']);
    if ($firstActivation) {
        $days = max(1, (int)$license['duration_days']);
        $sql = "UPDATE wolfox_licenses
                SET status='Active', activated_at=UTC_TIMESTAMP(),
                    expires_at=DATE_ADD(UTC_TIMESTAMP(), INTERVAL {$days} DAY),
                    installation_id=?, device_binding=?, app_version=?,
                    package_name=?, device_model=?, last_verified_at=UTC_TIMESTAMP()
                WHERE id=?";
        $pdo->prepare($sql)->execute([
            $installation, $binding, $appVersion, $packageName, $deviceModel, $license['id']
        ]);
    } else {
        $pdo->prepare("UPDATE wolfox_licenses
                       SET status='Active', app_version=?, package_name=?, device_model=?,
                           last_verified_at=UTC_TIMESTAMP()
                       WHERE id=?")
            ->execute([$appVersion, $packageName, $deviceModel, $license['id']]);
    }

    $statement = $pdo->prepare(
        'SELECT code,status,activated_at,expires_at,UNIX_TIMESTAMP(expires_at) expires_at_epoch,
                duration_days,last_verified_at FROM wolfox_licenses WHERE id=?'
    );
    $statement->execute([$license['id']]);
    $current = $statement->fetch();

    $pdo->prepare(
        'INSERT INTO wolfox_license_events
         (license_id,event_type,installation_id,package_name,request_id,ip)
         VALUES(?,?,?,?,?,?)'
    )->execute([
        $license['id'], $firstActivation ? 'activate' : 'verify', $installation,
        $packageName, $requestId, $_SERVER['REMOTE_ADDR'] ?? null
    ]);
    $pdo->commit();

    respond(200, [
        'status' => 'Active',
        'code' => $current['code'],
        'project' => $project,
        'activated_at' => $current['activated_at'],
        'expires_at' => $current['expires_at'],
        'expires_at_epoch' => (int)$current['expires_at_epoch'],
        'duration_days' => (int)$current['duration_days'],
        'last_verified_at' => $current['last_verified_at'],
        'request_id' => $requestId,
    ]);
} catch (Throwable $error) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    error_log('WolFox verify: ' . $error->getMessage());
    respond(500, ['status' => 'ServerError', 'request_id' => $requestId]);
}
