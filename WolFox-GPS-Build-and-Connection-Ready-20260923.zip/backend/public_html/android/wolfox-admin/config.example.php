<?php
declare(strict_types=1);

/* إعداد مستقل للوحة Android؛ لا تضمّن config.php الخاص بالمسار الأساسي هنا. */
const WOLFOX_ANDROID_DB_HOST = 'localhost';
const WOLFOX_ANDROID_DB_NAME = 'YOUR_DATABASE_NAME';
const WOLFOX_ANDROID_DB_USER = 'YOUR_DATABASE_USER';
const WOLFOX_ANDROID_DB_PASS = 'YOUR_DATABASE_PASSWORD';
const WOLFOX_ANDROID_BASE_URL = 'https://gps.p3nd.fun/android/wolfox-admin';
const WOLFOX_ANDROID_SESSION_NAME = 'wolfox_android_admin_session';

$pdo = new PDO(
    'mysql:host='.WOLFOX_ANDROID_DB_HOST.';dbname='.WOLFOX_ANDROID_DB_NAME.';charset=utf8mb4',
    WOLFOX_ANDROID_DB_USER,
    WOLFOX_ANDROID_DB_PASS,
    [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]
);
$pdo->exec("SET time_zone = '+00:00'");
