# ملاحظات إصلاح WolFox GPS 3.1.1

**التاريخ:** 22 سبتمبر 2026  
**النوع:** نسخة اختبار محلية فقط

## النتيجة

تحتوي هذه الشجرة على إصلاحات لموثوقية البناء وتقييد نطاق وحدة WolFox GPS بالمضيف المصرح به `sa.alfursan.it.apps.ontimeplus`. رُفع الإصدار إلى `3.1.1` و`313` داخل Gradle و`ModuleConfig` وبيانات وحدة LSPatch حتى تبقى الهوية متسقة.

## الإصلاحات

أصبح `build-local.sh` يفحص وجود `android.jar` وأدوات `aapt2` و`d8` و`zipalign` و`apksigner` قبل إزالة أي مخرجات سابقة. كما يرفض استخدام Java غير الإصدار 17، وهو ما يمنع فشل D8 المتأخر الذي ظهر مع Java 21 في بيئة الاختبار.

أصبح التوقيع الافتراضي آمنًا بالفشل. يتطلب بناء الإصدار متغيرات keystore الأربعة صراحةً. لا ينشئ السكربت مفتاحًا تلقائيًا إلا إذا حُدد `WOLFOX_ALLOW_TEST_KEYSTORE=1`، ويكون الناتج عندئذ موقّعًا بمفتاح اختبار مؤقت لا يصلح للنشر أو التحديث فوق أي تطبيق أو وحدة قائمة.

تحتوي بيانات الوحدة على نطاق LSPatch صريح، كما يتحقق `WolFoxHook` من اسم الحزمة قبل تثبيت أي خطاف. لا يُسمح للخطافات بالتحميل إلا في التطبيق المضيف المحدد.

## بناء إصدار حقيقي

لا تنفذ الأمر التالي إلا بعد توفير مفتاح إصدار المشروع المصرح به خارج المستودع:

```bash
export JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64
export PATH="$JAVA_HOME/bin:$PATH"
export ANDROID_SDK_ROOT=/path/to/android-sdk
export WOLFOX_KEYSTORE_PATH=/secure/path/release.jks
export WOLFOX_KEY_ALIAS=release_alias
export WOLFOX_KEYSTORE_PASS='...'
export WOLFOX_KEY_PASS='...'
./build-local.sh
```

بعد البناء، تحقّق من الحزمة باستخدام `apksigner verify --verbose --print-certs` وسجل بصمة شهادة الإصدار المعتمدة. ترتيب `zipalign` قبل التوقيع ضروري، لأن تعديل APK بعد توقيعه يبطل التوقيع.[1]

## قيد مهم

لا تستخدم ملف APK التجريبي الناتج من هذه الشجرة كتحديث لتطبيق أو وحدة مثبتة. يلزم استخدام مفتاح الإصدار المعتمد نفسه لإنشاء تحديث متوافق مع Android.

## References

[1]: https://developer.android.com/tools/apksigner "Android apksigner documentation"

## إصلاحات متابعة — 22 سبتمبر 2026 (patch 2)

- `AndroidManifest.xml`: صُحِّح `xposeddescription` من `3.1.0` إلى `3.1.1`
- `.github/workflows/build.yml`: صُحِّح مسار APK في خطوتَي Verify وUpload من `v3.1.0` إلى `v3.1.1_release_SIGNED`
- `ARTIFACT_SHA256.txt`: أُعيد هيكلته — إدخالات 3.0.9 أُرشفت، وأُضيف قسم 3.1.1 ينتظر بصمة البناء الرسمي
