package com.t2.AvailoHader;

import android.os.Bundle;
import android.view.MotionEvent;

import com.wolfox.gps.DirectBootstrap;

import org.apache.cordova.CordovaActivity;

/** Minimal host overlay: preserves the original Cordova startup and attaches WolFox UI. */
public class MainActivity extends CordovaActivity {
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        Bundle extras = getIntent().getExtras();
        if (extras != null && extras.getBoolean("cdvStartInBackground", false)) {
            moveTaskToBack(true);
        }
        loadUrl(launchUrl);
        DirectBootstrap.attach(this);
    }

    @Override public boolean dispatchTouchEvent(MotionEvent event) {
        DirectBootstrap.observeTouch(this, event);
        return super.dispatchTouchEvent(event);
    }
}
