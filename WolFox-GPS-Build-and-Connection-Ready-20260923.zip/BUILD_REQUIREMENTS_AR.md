# تجهيز بناء WolFox GPS 3.1.1

## من الجوال عبر GitHub Actions

ارفع **محتويات هذا المجلد** إلى جذر مستودع GitHub. يجب أن تكون ملفات
`build-local.sh` و`app/` و`stubs/` و`.github/workflows/build.yml` في جذر المستودع.
افتح تبويب **Actions** ثم اختر **Build WolFox GPS Module** واضغط **Run workflow**.
بعد نجاح التشغيل افتح صفحة التشغيل ونزّل ملف **WolFox-GPS-Module-v3.1.1** من
قسم Artifacts. يحتوي على APK اختبار موقّع بمفتاح مؤقت عند عدم تعيين أسرار الإصدار.

## بناء محلي

المطلوب: Linux وJDK 17 مع `javac` و`keytool`، و`zip` و`unzip`، وAndroid SDK
Platform 34 وBuild Tools 34.0.0. اضبط `ANDROID_SDK_ROOT` على مسار SDK، ثم:

```bash
chmod +x check-build.sh build-local.sh
./check-build.sh
WOLFOX_ALLOW_TEST_KEYSTORE=1 ./build-local.sh
```

إذا كان `sdkmanager` متاحًا وتحتاج حزم Android SDK، ثبّت
`platforms;android-34` و`build-tools;34.0.0` من Android SDK Manager ثم أعد الفحص.
لا يلزم Gradle للبناء المحلي المضمّن. APK الناتج في `build/local/apk/`.

## توقيع الإصدار

لإصدار يمكن تحديثه لاحقًا، استخدم مفتاحًا ثابتًا محفوظًا لديك. محليًا اضبط:
`WOLFOX_KEYSTORE_PATH` و`WOLFOX_KEY_ALIAS` و`WOLFOX_KEYSTORE_PASS` و`WOLFOX_KEY_PASS`.
في GitHub أضف أسرار المستودع `WOLFOX_KEYSTORE_BASE64` (محتويات ملف JKS بترميز
Base64) و`WOLFOX_KEY_ALIAS` و`WOLFOX_KEYSTORE_PASS` و`WOLFOX_KEY_PASS`.
لا ترفع ملف التوقيع أو كلمات مروره مع المصدر. مفتاح الاختبار مؤقت ولا يُستخدم
لتحديث تثبيتات الإصدار.

التحقق من التوقيع داخل مسار GitHub Actions يتم تلقائيًا عبر `apksigner`.
العمل دون روت يخص التطبيق المستهدف مع LSPatch/LSPosed متوافق وإعداد المضيف؛
لا يحوّل الموقع على مستوى نظام أندرويد. إعداد الخادم والترخيص موضح في
`backend/README_DEPLOY_AR.txt`.
