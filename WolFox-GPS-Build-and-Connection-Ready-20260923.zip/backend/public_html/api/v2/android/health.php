<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
require dirname(__DIR__, 3) . '/android/wolfox-admin/config.php';
try {
    $pdo->query('SELECT 1');
    echo json_encode(['status' => 'ok', 'service' => 'wolfox-android-v2', 'time' => gmdate('c')]);
} catch (Throwable $error) {
    http_response_code(503);
    echo json_encode(['status' => 'unavailable']);
}
