CREATE TABLE IF NOT EXISTS wolfox_admin_users (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(64) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('owner','admin','viewer') NOT NULL DEFAULT 'admin',
  active TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_login_at DATETIME NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS wolfox_licenses (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  code VARCHAR(64) NOT NULL UNIQUE,
  status ENUM('Unused','Active','Expired','Disabled') NOT NULL DEFAULT 'Unused',
  duration_days INT UNSIGNED NOT NULL DEFAULT 30,
  activated_at DATETIME NULL,
  expires_at DATETIME NULL,
  installation_id VARCHAR(191) NULL,
  device_binding VARCHAR(191) NULL,
  app_version VARCHAR(32) NULL,
  package_name VARCHAR(191) NULL,
  device_model VARCHAR(191) NULL,
  last_verified_at DATETIME NULL,
  note VARCHAR(255) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_status(status),
  INDEX idx_expires(expires_at),
  INDEX idx_installation(installation_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS wolfox_license_events (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  license_id BIGINT UNSIGNED NOT NULL,
  event_type ENUM('activate','verify','reset','disable','enable','extend') NOT NULL,
  installation_id VARCHAR(191) NULL,
  package_name VARCHAR(191) NULL,
  request_id VARCHAR(64) NULL,
  ip VARCHAR(64) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_license_time(license_id,created_at),
  INDEX idx_request(request_id),
  CONSTRAINT fk_wolfox_event_license FOREIGN KEY (license_id)
    REFERENCES wolfox_licenses(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS wolfox_admin_audit (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  actor VARCHAR(64) NULL,
  action VARCHAR(64) NOT NULL,
  license_code VARCHAR(64) NULL,
  details TEXT NULL,
  ip VARCHAR(64) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_action(action),
  INDEX idx_license_code(license_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS wolfox_app_control (
  package_name VARCHAR(191) PRIMARY KEY,
  enabled TINYINT(1) NOT NULL DEFAULT 1,
  maintenance TINYINT(1) NOT NULL DEFAULT 0,
  min_version_code INT UNSIGNED NOT NULL DEFAULT 0,
  force_update TINYINT(1) NOT NULL DEFAULT 0,
  message_title VARCHAR(191) NULL,
  message_text VARCHAR(500) NULL,
  store_deep_link VARCHAR(500) NULL,
  update_page VARCHAR(500) NULL,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO wolfox_app_control(package_name,enabled,maintenance,min_version_code,force_update)
VALUES('com.wolfox.gps',1,0,0,0)
ON DUPLICATE KEY UPDATE package_name=VALUES(package_name);
