<?php require __DIR__.'/bootstrap.php'; audit($pdo,'logout'); session_destroy(); header('Location: login.php');
