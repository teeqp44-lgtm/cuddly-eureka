ALTER TABLE wolfox_licenses
  ADD COLUMN IF NOT EXISTS package_name VARCHAR(191) NULL AFTER app_version,
  ADD COLUMN IF NOT EXISTS device_model VARCHAR(191) NULL AFTER package_name,
  ADD COLUMN IF NOT EXISTS last_verified_at DATETIME NULL AFTER device_model;

CREATE TABLE IF NOT EXISTS wolfox_license_events (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  license_id BIGINT UNSIGNED NOT NULL,
  event_type ENUM('activate','verify','reset','disable','enable','extend') NOT NULL,
  installation_id VARCHAR(191) NULL,
  package_name VARCHAR(191) NULL,
  request_id VARCHAR(64) NULL,
  ip VARCHAR(64) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_license_time(license_id,created_at),
  INDEX idx_request(request_id),
  CONSTRAINT fk_wolfox_event_license FOREIGN KEY (license_id)
    REFERENCES wolfox_licenses(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
