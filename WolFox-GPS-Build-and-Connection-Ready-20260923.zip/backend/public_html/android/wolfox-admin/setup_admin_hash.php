<?php
declare(strict_types=1);
header('Cache-Control: no-store');
$error = '';
$hash = '';
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $password = (string)($_POST['password'] ?? '');
    if (strlen($password) < 12) $error = 'استخدم كلمة مرور من 12 حرفًا على الأقل.';
    else $hash = password_hash($password, PASSWORD_DEFAULT);
}
?><!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>WolFox Setup</title><link rel="stylesheet" href="style.css"></head><body><main class="login"><form class="card" method="post"><h1>إعداد مدير WolFox</h1><p class="muted">ولّد الـHash مرة واحدة، ثم احذف هذا الملف فورًا.</p><?php if($error):?><div class="alert"><?=htmlspecialchars($error,ENT_QUOTES,'UTF-8')?></div><?php endif?><label>كلمة المرور<input type="password" name="password" minlength="12" required autocomplete="new-password"></label><button>توليد Hash</button><?php if($hash):?><label>انسخ القيمة التالية<textarea readonly rows="4"><?=htmlspecialchars($hash,ENT_QUOTES,'UTF-8')?></textarea></label><?php endif?></form></main></body></html>
