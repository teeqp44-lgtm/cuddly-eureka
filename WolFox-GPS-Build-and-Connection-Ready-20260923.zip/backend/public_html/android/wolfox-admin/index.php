<?php
declare(strict_types=1);
require __DIR__ . '/bootstrap.php';
require_login();

$notice = (string)($_SESSION['notice'] ?? '');
unset($_SESSION['notice']);
$pdo->exec("UPDATE wolfox_licenses SET status='Expired'
            WHERE status='Active' AND expires_at IS NOT NULL AND expires_at<=UTC_TIMESTAMP()");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    require_write_access();
    $action = (string)($_POST['action'] ?? '');
    $code = strtoupper(trim((string)($_POST['code'] ?? '')));

    if ($action === 'save_control') {
        $package = trim((string)($_POST['package_name'] ?? 'com.wolfox.gps'));
        if (!preg_match('/^[A-Za-z][A-Za-z0-9_.]{2,190}$/', $package)) {
            $_SESSION['notice'] = 'اسم الحزمة غير صالح';
            header('Location: index.php');
            exit;
        }
        $enabled = isset($_POST['enabled']) ? 1 : 0;
        $maintenance = isset($_POST['maintenance']) ? 1 : 0;
        $forceUpdate = isset($_POST['force_update']) ? 1 : 0;
        $minimumVersion = max(0, min(2147483647, (int)($_POST['min_version_code'] ?? 0)));
        $title = substr(trim((string)($_POST['message_title'] ?? '')), 0, 191);
        $message = substr(trim((string)($_POST['message_text'] ?? '')), 0, 500);
        $deepLink = substr(trim((string)($_POST['store_deep_link'] ?? '')), 0, 500);
        $updatePage = substr(trim((string)($_POST['update_page'] ?? '')), 0, 500);
        $serverHost = strtolower((string)parse_url(WOLFOX_ANDROID_BASE_URL, PHP_URL_HOST));
        if ($deepLink !== '' && !preg_match('#^wolfoxstore://app(?:\\?|$)#i', $deepLink)) {
            $_SESSION['notice'] = 'رابط المتجر الداخلي غير صالح';
            header('Location: index.php');
            exit;
        }
        if ($updatePage !== '' && (
            strtolower((string)parse_url($updatePage, PHP_URL_SCHEME)) !== 'https'
            || strtolower((string)parse_url($updatePage, PHP_URL_HOST)) !== $serverHost
        )) {
            $_SESSION['notice'] = 'رابط صفحة التحديث يجب أن يكون HTTPS على نطاق الخادم نفسه';
            header('Location: index.php');
            exit;
        }
        $statement = $pdo->prepare(
            'INSERT INTO wolfox_app_control
             (package_name,enabled,maintenance,min_version_code,force_update,message_title,
              message_text,store_deep_link,update_page)
             VALUES(?,?,?,?,?,?,?,?,?)
             ON DUPLICATE KEY UPDATE enabled=VALUES(enabled),maintenance=VALUES(maintenance),
              min_version_code=VALUES(min_version_code),force_update=VALUES(force_update),
              message_title=VALUES(message_title),message_text=VALUES(message_text),
              store_deep_link=VALUES(store_deep_link),update_page=VALUES(update_page)'
        );
        $statement->execute([
            $package, $enabled, $maintenance, $minimumVersion, $forceUpdate, $title,
            $message, $deepLink, $updatePage
        ]);
        audit($pdo, 'save_app_control', null, $package);
        $_SESSION['notice'] = 'تم حفظ تحكم الموديول';
        header('Location: index.php');
        exit;
    }

    if ($action === 'create') {
        $days = max(1, min(3650, (int)($_POST['days'] ?? 30)));
        $count = max(1, min(500, (int)($_POST['count'] ?? 1)));
        $note = substr(trim((string)($_POST['note'] ?? '')), 0, 255);
        $statement = $pdo->prepare(
            'INSERT INTO wolfox_licenses(code,duration_days,note) VALUES(?,?,?)'
        );
        for ($i = 0; $i < $count; $i++) $statement->execute([make_code(), $days, $note]);
        audit($pdo, 'create_batch', null, "count={$count} days={$days}");
        $notice = "تم إنشاء {$count} كود";
    }

    if ($action === 'import') {
        $lines = preg_split('/\R/u', (string)($_POST['codes_text'] ?? '')) ?: [];
        $statement = $pdo->prepare(
            'INSERT IGNORE INTO wolfox_licenses(code,duration_days,note) VALUES(?,?,?)'
        );
        $added = 0;
        foreach (array_slice($lines, 0, 2000) as $line) {
            $line = trim($line);
            if ($line === '') continue;
            $parts = array_map('trim', explode('|', $line, 3));
            $importCode = strtoupper((string)($parts[0] ?? ''));
            $importCode = preg_replace('/[^A-Z0-9]/', '', $importCode) ?: '';
            if ($importCode === '' || strlen($importCode) > 64) continue;
            $days = max(1, min(3650, (int)($parts[1] ?? 30)));
            $note = substr((string)($parts[2] ?? ''), 0, 255);
            $statement->execute([$importCode, $days, $note]);
            $added += $statement->rowCount();
        }
        audit($pdo, 'import_codes', null, "added={$added}");
        $notice = "تم استيراد {$added} كود";
    }

    if ($code !== '' && in_array($action,
            ['disable', 'enable', 'reset', 'extend', 'delete'], true)) {
        if ($action === 'disable') {
            $pdo->prepare("UPDATE wolfox_licenses SET status='Disabled' WHERE code=?")
                ->execute([$code]);
        } elseif ($action === 'enable') {
            $pdo->prepare("UPDATE wolfox_licenses
                           SET status=IF(expires_at IS NULL,'Unused',
                             IF(expires_at>UTC_TIMESTAMP(),'Active','Expired')) WHERE code=?")
                ->execute([$code]);
        } elseif ($action === 'reset') {
            $pdo->prepare("UPDATE wolfox_licenses
                           SET installation_id=NULL,device_binding=NULL,status='Unused',
                               activated_at=NULL,expires_at=NULL,package_name=NULL,
                               device_model=NULL,last_verified_at=NULL WHERE code=?")
                ->execute([$code]);
        } elseif ($action === 'extend') {
            $days = max(1, min(3650, (int)($_POST['days'] ?? 30)));
            $sql = "UPDATE wolfox_licenses
                    SET expires_at=DATE_ADD(
                      IF(expires_at IS NULL OR expires_at<UTC_TIMESTAMP(),UTC_TIMESTAMP(),expires_at),
                      INTERVAL {$days} DAY), status='Active' WHERE code=?";
            $pdo->prepare($sql)->execute([$code]);
        } elseif ($action === 'delete' && ($_SESSION['role'] ?? '') === 'owner') {
            $pdo->prepare('DELETE FROM wolfox_licenses WHERE code=?')->execute([$code]);
        }
        audit($pdo, $action, $code);
        $notice = 'تم تنفيذ العملية';
    }
    $_SESSION['notice'] = $notice;
    header('Location: index.php');
    exit;
}

$stats = [];
foreach (['Unused','Active','Expired','Disabled'] as $state) {
    $statement = $pdo->prepare('SELECT COUNT(*) c FROM wolfox_licenses WHERE status=?');
    $statement->execute([$state]);
    $stats[$state] = (int)$statement->fetch()['c'];
}
$expiring = (int)$pdo->query(
    "SELECT COUNT(*) c FROM wolfox_licenses WHERE status='Active'
     AND expires_at BETWEEN UTC_TIMESTAMP() AND DATE_ADD(UTC_TIMESTAMP(),INTERVAL 7 DAY)"
)->fetch()['c'];

$control = [
    'package_name' => 'com.wolfox.gps', 'enabled' => 1, 'maintenance' => 0,
    'min_version_code' => 0, 'force_update' => 0, 'message_title' => '',
    'message_text' => '', 'store_deep_link' => '', 'update_page' => ''
];
$controlReady = true;
try {
    $statement = $pdo->prepare('SELECT * FROM wolfox_app_control WHERE package_name=? LIMIT 1');
    $statement->execute([$control['package_name']]);
    $savedControl = $statement->fetch();
    if ($savedControl) $control = array_merge($control, $savedControl);
} catch (Throwable $error) {
    $controlReady = false;
}

$query = trim((string)($_GET['q'] ?? ''));
$status = trim((string)($_GET['status'] ?? ''));
$sql = 'SELECT * FROM wolfox_licenses WHERE 1';
$args = [];
if ($query !== '') {
    $sql .= ' AND (code LIKE ? OR installation_id LIKE ? OR package_name LIKE ? OR note LIKE ?)';
    array_push($args, "%{$query}%", "%{$query}%", "%{$query}%", "%{$query}%");
}
if (in_array($status, ['Unused','Active','Expired','Disabled'], true)) {
    $sql .= ' AND status=?';
    $args[] = $status;
}
$sql .= ' ORDER BY id DESC LIMIT 500';
$statement = $pdo->prepare($sql);
$statement->execute($args);
$rows = $statement->fetchAll();
?>
<!doctype html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>WolFox Admin</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="wrap">
  <div class="top card">
    <div><h1>WolFox</h1><div class="muted">لوحة تراخيص Android · v3</div></div>
    <div class="top-links">
      <span class="role"><?=h((string)($_SESSION['role'] ?? ''))?></span>
      <a href="export.php">تصدير CSV</a><a href="logout.php">خروج</a>
    </div>
  </div>

  <?php if ($notice !== ''): ?><div class="notice"><?=h($notice)?></div><?php endif ?>

  <div class="grid stats">
    <?php foreach ($stats as $key => $value): ?>
      <div class="card"><div class="muted"><?=h($key)?></div><div class="stat"><?=h((string)$value)?></div></div>
    <?php endforeach ?>
    <div class="card"><div class="muted">تنتهي خلال 7 أيام</div><div class="stat warn"><?=h((string)$expiring)?></div></div>
  </div>

  <?php if (($_SESSION['role'] ?? 'viewer') !== 'viewer'): ?>
  <div class="card">
    <h2>تحكم الموديول والتحديث الإجباري</h2>
    <?php if (!$controlReady): ?>
      <div class="alert">استورد ملف sql/migrate_v3_to_v3_1.sql لتفعيل هذا القسم.</div>
    <?php else: ?>
    <form method="post">
      <input type="hidden" name="csrf" value="<?=h(csrf())?>">
      <input type="hidden" name="action" value="save_control">
      <div class="grid">
        <label>اسم الحزمة<input name="package_name" value="<?=h((string)$control['package_name'])?>" required></label>
        <label>أقل Version Code<input name="min_version_code" type="number" min="0" value="<?=h((string)$control['min_version_code'])?>"></label>
        <label>العنوان<input name="message_title" maxlength="191" value="<?=h((string)$control['message_title'])?>" placeholder="تحديث إجباري"></label>
        <label>النص<input name="message_text" maxlength="500" value="<?=h((string)$control['message_text'])?>" placeholder="حدّث الموديول للمتابعة"></label>
        <label>رابط WolFox Store<input name="store_deep_link" value="<?=h((string)$control['store_deep_link'])?>" placeholder="wolfoxstore://app?package=com.wolfox.gps"></label>
        <label>صفحة تحديث HTTPS<input name="update_page" value="<?=h((string)$control['update_page'])?>" placeholder="https://gps.p3nd.fun/..."></label>
      </div>
      <div class="checks">
        <label><input type="checkbox" name="enabled" <?=$control['enabled']?'checked':''?>> الموديول مفعّل</label>
        <label><input type="checkbox" name="maintenance" <?=$control['maintenance']?'checked':''?>> وضع الصيانة</label>
        <label><input type="checkbox" name="force_update" <?=$control['force_update']?'checked':''?>> تحديث إجباري للإصدارات الأقدم</label>
      </div>
      <button>حفظ تحكم الموديول</button>
    </form>
    <?php endif ?>
  </div>
  <div class="two-cols">
    <div class="card">
      <h2>إنشاء أكواد</h2>
      <form method="post">
        <input type="hidden" name="csrf" value="<?=h(csrf())?>">
        <input type="hidden" name="action" value="create">
        <div class="grid">
          <label>المدة بالأيام<input name="days" type="number" min="1" max="3650" value="30"></label>
          <label>العدد<input name="count" type="number" min="1" max="500" value="10"></label>
          <label>ملاحظة<input name="note" maxlength="255" placeholder="اختياري"></label>
          <label>&nbsp;<button>إنشاء</button></label>
        </div>
      </form>
    </div>
    <div class="card">
      <h2>استيراد أكواد</h2>
      <form method="post">
        <input type="hidden" name="csrf" value="<?=h(csrf())?>">
        <input type="hidden" name="action" value="import">
        <textarea name="codes_text" rows="4" placeholder="CODE|30|ملاحظة — كود في كل سطر"></textarea>
        <button>استيراد بدون تكرار</button>
      </form>
    </div>
  </div>
  <?php endif ?>

  <div class="card">
    <form method="get" class="grid">
      <label>بحث<input name="q" value="<?=h($query)?>" placeholder="الكود / الجهاز / الباندل / الملاحظة"></label>
      <label>الحالة<select name="status"><option value="">كل الحالات</option>
        <?php foreach (['Unused','Active','Expired','Disabled'] as $state): ?>
          <option value="<?=h($state)?>" <?=$status===$state?'selected':''?>><?=h($state)?></option>
        <?php endforeach ?>
      </select></label>
      <label>&nbsp;<button>بحث</button></label>
    </form>
  </div>

  <div class="card scroll">
    <table>
      <thead><tr><th>الكود</th><th>الحالة</th><th>المدة</th><th>الانتهاء</th><th>الباندل</th><th>آخر تحقق</th><th>الجهاز</th><th>ملاحظة</th><th>إدارة</th></tr></thead>
      <tbody>
      <?php foreach ($rows as $row): ?>
        <tr>
          <td><button type="button" class="copy" data-code="<?=h($row['code'])?>"><?=h($row['code'])?></button></td>
          <td class="<?=$row['status']==='Active'?'ok':($row['status']==='Disabled'?'bad':'warn')?>"><?=h($row['status'])?></td>
          <td><?=h((string)$row['duration_days'])?> يوم</td>
          <td><?=h((string)($row['expires_at'] ?? '-'))?></td>
          <td><?=h((string)($row['package_name'] ?? '-'))?></td>
          <td><?=h((string)($row['last_verified_at'] ?? '-'))?></td>
          <td title="<?=h((string)($row['device_binding'] ?? ''))?>"><?=h((string)($row['device_model'] ?? $row['installation_id'] ?? '-'))?></td>
          <td><?=h((string)($row['note'] ?? ''))?></td>
          <td>
          <?php if (($_SESSION['role'] ?? 'viewer') !== 'viewer'): ?>
            <form class="inline" method="post">
              <input type="hidden" name="csrf" value="<?=h(csrf())?>"><input type="hidden" name="code" value="<?=h($row['code'])?>">
              <button name="action" value="reset" class="gray">Reset</button>
              <button name="action" value="enable">Enable</button>
              <button name="action" value="disable" class="danger">Disable</button>
              <input name="days" type="number" min="1" max="3650" value="30" class="days">
              <button name="action" value="extend">تمديد</button>
              <?php if (($_SESSION['role'] ?? '') === 'owner'): ?><button name="action" value="delete" class="danger" onclick="return confirm('حذف نهائي؟')">حذف</button><?php endif ?>
            </form>
          <?php else: ?>—<?php endif ?>
          </td>
        </tr>
      <?php endforeach ?>
      </tbody>
    </table>
  </div>
</div>
<script>
document.querySelectorAll('.copy').forEach(function(button){
  button.addEventListener('click',function(){ navigator.clipboard.writeText(button.dataset.code || ''); button.textContent='تم النسخ'; setTimeout(function(){button.textContent=button.dataset.code;},900); });
});
</script>
</body>
</html>
