# WolFox GPS — متطلبات حساب GitHub والبناء

المستودع المستهدف: https://github.com/teeqp44-lgtm/cuddly-eureka

## 1) وصول حساب GitHub للرفع من هذه الجلسة

- ثبّت تطبيق GitHub المتصل بـ ChatGPT على حساب `teeqp44-lgtm` واختر المستودع `cuddly-eureka` ضمن Repository access.
- يجب أن يطلب التطبيق الصلاحيات التالية ويوافق صاحب الحساب عليها: `Contents: Read and write` لرفع ملفات المصدر؛ `Workflows: Read and write` لإنشاء/تحديث `.github/workflows/build.yml`؛ `Actions: Read` لفحص التشغيل وتنزيل الـ Artifact. إذا كان المطلوب تشغيل workflow_dispatch عن بعد عبر API، قد تلزم `Actions: Read and write` بحسب الأداة المستخدمة.
- قد يملك المستخدم صلاحية admin على المستودع بينما يظل تطبيق التكامل دون صلاحية الكتابة. هذا ما يظهر عند `403 Resource not accessible by integration`.
- لا يمكن لصاحب المستودع أن يضيف صلاحية لم يطلبها تطبيق GitHub أصلاً. في هذه الحالة يلزم تطبيق/اتصال آخر يدعمها أو تعديل صلاحيات التطبيق من مالكه ثم الموافقة عليها.
- لا تلصق رموز الوصول أو كلمات المرور في المحادثة، ولا ترفعها إلى المستودع. الرمز السابق الذي ظهر في المحادثة ينبغي إلغاؤه.

الحالة المفحوصة: أداة GitHub تتعرف على المستخدم `teeqp44-lgtm` وتقرأ المستودع، لكن محاولتي كتابة ملف وBlob أعادتا 403، وقائمة تثبيتات التطبيق المتاحة لهذه الجلسة فارغة. لم تُمنح الصلاحيات أعلاه من جانبي.

## 2) جذر المشروع

المجلدات/الملفات اللازمة في جذر المستودع مباشرة:

- `.github/workflows/build.yml`
- `app/` مع `app/src/main/AndroidManifest.xml` وJava والموارد وassets
- `stubs/` لواجهات Xposed أثناء البناء
- `build-local.sh` و`check-build.sh`
- مستندات المشروع والاختبارات و`backend/` و`web-preview/` ضمن الحزمة

رفع `wolfox_map.html` أو الأيقونة أو `xposed_init` وحدها لا يكفي. يجب الحفاظ على المسارات داخل `app/src/main/assets/` كما هي.

## 3) البناء في GitHub Actions

`build.yml` يستخدم Ubuntu، يثبت Java 17 وAndroid Platform 34 وBuild Tools 34.0.0، ويفحص المتطلبات ثم يبني APK ويفحص توقيعه وينشره كـ Artifact لمدة 30 يومًا. الدفع إلى فرع `main` أو التشغيل اليدوي يبدأ المهمة. يخرج APK اختبار موقّعًا بمفتاح مؤقت إذا لم تُضبط أسرار توقيع الإصدار.

بعد نجاح التشغيل، نزّل Artifact المسمى `WolFox-GPS-Module-v3.1.1` من صفحة التشغيل. للتوقيع المستمر أضف أسرار `WOLFOX_KEYSTORE_BASE64` و`WOLFOX_KEY_ALIAS` و`WOLFOX_KEYSTORE_PASS` و`WOLFOX_KEY_PASS`، واحتفظ بمفتاح JKS الأصلي في مكان آمن خارج المستودع.

## 4) حدود التحقق

الحزمة هي مصدر جاهز للبناء. لا تحتوي على SDK أو APK مبني. فحوص Python وJavaScript وXML وShell نجحت، لكن بناء APK كامل يحتاج بيئة GitHub Actions أو جهازًا يحوي SDK. التشغيل داخل التطبيق دون root يتطلب إعداد LSPatch/LSPosed متوافقًا وربط الترخيص والخادم؛ هو ليس تغييرًا عامًا لموقع نظام أندرويد.
