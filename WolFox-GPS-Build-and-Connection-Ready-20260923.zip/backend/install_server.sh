#!/usr/bin/env bash
set -euo pipefail

bundle_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source_public="$bundle_dir/public_html"
default_public="/home/u460057331/domains/gps.p3nd.fun/public_html"
server_public="${1:-$default_public}"

if [[ ! -d "$source_public" ]]; then
  echo "خطأ: مجلد public_html غير موجود داخل الحزمة." >&2
  exit 2
fi
if [[ ! -d "$server_public" || "$(basename "$server_public")" != "public_html" ]]; then
  echo "خطأ: المسار يجب أن يكون مجلد public_html موجودًا: $server_public" >&2
  exit 3
fi

api_target="$server_public/api/v2/android"
admin_target="$server_public/android/wolfox-admin"
stamp="$(date -u +%Y%m%d-%H%M%S)"
backup_root="$server_public/android/wolfox-admin-backups/$stamp"

mkdir -p "$backup_root"
if [[ -d "$api_target" ]]; then
  mkdir -p "$backup_root/api-v2-android"
  cp -a "$api_target/." "$backup_root/api-v2-android/"
fi
if [[ -d "$admin_target" ]]; then
  mkdir -p "$backup_root/wolfox-admin"
  cp -a "$admin_target/." "$backup_root/wolfox-admin/"
fi

mkdir -p "$api_target" "$admin_target"
cp -a "$source_public/api/v2/android/." "$api_target/"
cp -a "$source_public/android/wolfox-admin/." "$admin_target/"

# لا تحتوي الحزمة على config.php، لذلك يبقى إعداد لوحة Android الحالي كما هو.
if [[ ! -f "$admin_target/config.php" ]]; then
  cp "$admin_target/config.example.php" "$admin_target/config.php"
  chmod 0600 "$admin_target/config.php"
  echo "تنبيه: أنشئنا config.php بقيم فارغة. عدّله ببيانات قاعدة Android فقط." >&2
fi

find "$api_target" "$admin_target" -type d -exec chmod 0755 {} +
find "$api_target" "$admin_target" -type f ! -name 'config.php' -exec chmod 0644 {} +

echo "تم تركيب ملفات WolFox Android فقط."
echo "النسخة الاحتياطية: $backup_root"
echo "نفّذ ترقية قاعدة البيانات من: $bundle_dir/sql/migrate_v3_to_v3_1.sql"
echo "الفحص: https://gps.p3nd.fun/api/v2/android/health.php"
echo "اللوحة: https://gps.p3nd.fun/android/wolfox-admin/"
