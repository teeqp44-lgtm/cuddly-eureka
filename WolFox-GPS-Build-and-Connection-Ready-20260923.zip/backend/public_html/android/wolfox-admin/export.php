<?php require __DIR__.'/bootstrap.php'; require_login();
header('Content-Type: text/csv; charset=utf-8'); header('Content-Disposition: attachment; filename=wolfox_licenses.csv');
$out=fopen('php://output','w'); fputcsv($out,['code','status','duration_days','activated_at','expires_at','installation_id','app_version','note']);
foreach($pdo->query('SELECT code,status,duration_days,activated_at,expires_at,installation_id,app_version,note FROM wolfox_licenses ORDER BY id DESC') as $r){fputcsv($out,$r);} exit;
