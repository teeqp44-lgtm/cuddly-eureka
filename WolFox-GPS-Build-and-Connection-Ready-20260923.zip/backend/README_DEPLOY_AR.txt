حزمة WolFox GPS v3.1 — gps.p3nd.fun / Hostinger / MySQL

المسارات المستقلة
- API: /public_html/api/v2/android/
- لوحة Android: /public_html/android/wolfox-admin/
- لا تُنسخ أي ملفات إلى جذر public_html ولا يتم تعديل config.php للوحة الأساسية.

التنفيذ السريع بعد فك الضغط
  chmod +x install_server.sh
  bash install_server.sh

التنفيذ الكامل عند توفر root على الخادم
  sudo bash backend/root_local_setup.sh

هذا الأمر يضبط 0755 للأدوات التنفيذية و0750 لمجلدات العمل و0600 للأسرار،
ثم يشغّل فحصًا محليًا شاملًا. لا ينزّل أي حزم من الإنترنت.

يستخدم السكربت تلقائيًا:
  /home/u460057331/domains/gps.p3nd.fun/public_html
ويمكن تمرير مسار مختلف كوسيط أول. يحفظ نسخة احتياطية ولا يستبدل
android/wolfox-admin/config.php الموجود.

التثبيت الجديد
1) أنشئ قاعدة MySQL ومستخدمًا من Hostinger.
2) استورد sql/schema.sql من phpMyAdmin.
3) ارفع محتويات public_html إلى جذر نطاق gps.p3nd.fun.
4) إذا لم يكن موجودًا، انسخ android/wolfox-admin/config.example.php إلى
   android/wolfox-admin/config.php ثم ضع بيانات MySQL الخاصة بلوحة Android فقط.
5) افتح https://gps.p3nd.fun/android/wolfox-admin/setup_admin_hash.php وأنشئ Hash لكلمة مرور قوية.
6) أضف المدير من phpMyAdmin:
   INSERT INTO wolfox_admin_users(username,password_hash,role)
   VALUES('admin','HASH_HERE','owner');
7) احذف setup_admin_hash.php فورًا.
8) افتح https://gps.p3nd.fun/android/wolfox-admin.

الترقية من لوحة v2
1) خذ نسخة احتياطية من قاعدة البيانات.
2) استورد sql/migrate_v2_to_v3.sql.
3) شغّل install_server.sh؛ سيستبدل ملفات Android المطلوبة فقط مع الاحتفاظ
   بملف android/wolfox-admin/config.php الحالي.
4) استورد sql/migrate_v3_to_v3_1.sql لإضافة تحكم الموديول والتحديث الإجباري.

الاختبار
- فحص الخدمة: https://gps.p3nd.fun/api/v2/android/health.php
- رابط تفعيل الموديول: https://gps.p3nd.fun/api/v2/android/verify.php
- رابط تحكم الموديول: https://gps.p3nd.fun/api/v2/android/store/config.php?package_name=com.wolfox.gps&version_code=312
- لوحة الإدارة: https://gps.p3nd.fun/android/wolfox-admin
- أنشئ كودًا لمدة يوم واحد وجرب التفعيل ثم Reset من اللوحة وأعد التفعيل.

مهم
- لا ترفع config.php أو بيانات MySQL إلى GitHub.
- الأكواد الجديدة بصيغة WFX بدون فواصل، مع استمرار دعم الأكواد القديمة.
- استخدم HTTPS فقط.
- يحتفظ التطبيق بالترخيص حتى تاريخ الانتهاء، ولا يوقفه انقطاع الشبكة.
- Reset يفك ربط الجهاز ولا يمدد المدة؛ التفعيل التالي يبدأ مدة جديدة.
- تمت إزالة منطق اعتراض Google Play من الموديول بالكامل.
