#!/usr/bin/env bash
set -euo pipefail

# هذا السكربت خاص بصلاحيات خادم Linux فقط. لا يضيف Root إلى Android ولا يخفيه.
if [[ "$(id -u)" -ne 0 ]]; then
  echo "شغّل هذا الملف بصلاحية root: sudo bash backend/root_local_setup.sh" >&2
  exit 77
fi

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
account_user="${WOLFOX_ACCOUNT_USER:-u460057331}"
account_root="${WOLFOX_ACCOUNT_ROOT:-/home/$account_user}"
server_public="${WOLFOX_PUBLIC_HTML:-$account_root/domains/gps.p3nd.fun/public_html}"
panel_root="${WOLFOX_PANEL_ROOT:-$server_public/android/wolfox-admin}"
sdk_root="${ANDROID_SDK_ROOT:-$account_root/android-sdk}"
build_tools="${ANDROID_BUILD_TOOLS:-$sdk_root/build-tools/34.0.0}"
java_bin="${JAVA_BIN:-$sdk_root/jdk-17/bin/java}"

if ! id "$account_user" >/dev/null 2>&1; then
  echo "المستخدم غير موجود: $account_user" >&2
  exit 2
fi
if [[ ! -d "$server_public" || "$(basename "$server_public")" != "public_html" ]]; then
  echo "مسار public_html غير صحيح: $server_public" >&2
  exit 3
fi

account_group="$(id -gn "$account_user")"
echo "[1/5] تركيب ملفات Android المستقلة مع نسخة احتياطية"
bash "$script_dir/install_server.sh" "$server_public"

echo "[2/5] الملكية والصلاحيات"
for target in "$server_public/api/v2/android" "$panel_root"; do
  chown -R "$account_user:$account_group" "$target"
  find "$target" -type d -exec chmod 0755 {} +
  find "$target" -type f -exec chmod 0644 {} +
done
[[ ! -f "$panel_root/config.php" ]] || chmod 0600 "$panel_root/config.php"

mkdir -p "$panel_root/storage/build-jobs" "$panel_root/storage/uploads" "$panel_root/storage/output"
chown -R "$account_user:$account_group" "$panel_root/storage"
chmod 0750 "$panel_root/storage" "$panel_root/storage/build-jobs" \
  "$panel_root/storage/uploads" "$panel_root/storage/output"

echo "[3/5] تصحيح تشغيل الأدوات المحلية"
for directory in \
  "$sdk_root" "$sdk_root/jdk-17" "$sdk_root/jdk-17/bin" \
  "$sdk_root/build-tools" "$build_tools"
do
  [[ ! -d "$directory" ]] || chmod 0755 "$directory"
done
for executable in "$java_bin" "$build_tools/aapt2" "$build_tools/apksigner" "$build_tools/zipalign"; do
  [[ ! -f "$executable" ]] || chmod 0755 "$executable"
done

for builder in "$panel_root/builder-" "$panel_root/builder"; do
  if [[ -f "$builder/tools/safe_patch.py" ]]; then
    chmod 0755 "$builder/tools/safe_patch.py"
  fi
done

secret_dir="$account_root/.secrets"
keystore="${WOLFOX_KEYSTORE_PATH:-$secret_dir/wolfox-release.jks}"
if [[ -d "$secret_dir" ]]; then
  chown "$account_user:$account_group" "$secret_dir"
  chmod 0700 "$secret_dir"
fi
if [[ -f "$keystore" ]]; then
  chown "$account_user:$account_group" "$keystore"
  chmod 0600 "$keystore"
fi

echo "[4/5] فحص المتطلبات بحساب الموقع"
check_env=(
  "WOLFOX_ACCOUNT_ROOT=$account_root"
  "WOLFOX_PANEL_ROOT=$panel_root"
  "ANDROID_SDK_ROOT=$sdk_root"
  "ANDROID_BUILD_TOOLS=$build_tools"
  "JAVA_BIN=$java_bin"
  "WOLFOX_KEYSTORE_PATH=$keystore"
)
if command -v runuser >/dev/null 2>&1; then
  runuser -u "$account_user" -- env "${check_env[@]}" bash "$script_dir/check_server_requirements.sh"
else
  su -s /bin/bash "$account_user" -c "env $(printf '%q ' "${check_env[@]}") bash $(printf '%q' "$script_dir/check_server_requirements.sh")"
fi

echo "[5/5] اكتمل"
echo "اللوحة: https://gps.p3nd.fun/android/wolfox-admin/"
echo "الفحص: https://gps.p3nd.fun/api/v2/android/health.php"
echo "لم يتم تنزيل أي أداة ولم يتغير أي ملف في جذر public_html."

